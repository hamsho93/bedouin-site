export type AmplifyDependentResourcesAttributes = {
  "api": {
    "bedouinsite": {
      "GraphQLAPIEndpointOutput": "string",
      "GraphQLAPIIdOutput": "string",
      "GraphQLAPIKeyOutput": "string"
    }
  }
}